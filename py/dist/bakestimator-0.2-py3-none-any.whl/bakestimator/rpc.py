import requests

from .tenderbake import calc_active_stake

DEFAULT_URL = "https://rpc.ithacanet.teztnets.xyz"
RPC_DELEGATES = "/chains/main/blocks/head/context/delegates"


def active_delegates(url=DEFAULT_URL):
    return requests.get(f"{url}/{RPC_DELEGATES}?active").json()


def active_delegates_info(active_delegates=None, url=DEFAULT_URL):
    if active_delegates is None:
        active_delegates = active_delegates(url=url)
    return [
        requests.get(f"{url}/{active_delegates}/{addr}").json()
        for addr in active_delegates
    ]


# currently total active rolls on ithacanet 5999
# real active stake is 5873.79 rolls
def real_total_active_stake(delegates):
    return (
        sum(
            calc_active_stake(int(d["staking_balance"]), int(d["full_balance"]))
            for d in delegates
        )
        / 1000000
    )
